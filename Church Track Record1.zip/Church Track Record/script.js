document.addEventListener("DOMContentLoaded", () => {
    loadRecords();
});

document.getElementById("attendanceForm").addEventListener("submit", function(event) {
    event.preventDefault();

    const name = document.getElementById("name").value;
    const gender = document.getElementById("gender").value;
    const visitor = document.getElementById("visitor").value;

    const newRecord = { name, gender, visitor };

    let records = JSON.parse(localStorage.getItem("churchRecords")) || [];
    records.push(newRecord);
    localStorage.setItem("churchRecords", JSON.stringify(records));

    document.getElementById("attendanceForm").reset();
    loadRecords();
});

function loadRecords() {
    let records = JSON.parse(localStorage.getItem("churchRecords")) || [];

    let totalAttendance = records.length;
    let totalVisitors = records.filter(record => record.visitor === "yes").length;
    let totalMales = records.filter(record => record.gender === "male").length;
    let totalFemales = records.filter(record => record.gender === "female").length;
    let totalChildren = records.filter(record => record.gender === "child").length;

    document.getElementById("totalAttendance").textContent = totalAttendance;
    document.getElementById("totalVisitors").textContent = totalVisitors;
    document.getElementById("totalMales").textContent = totalMales;
    document.getElementById("totalFemales").textContent = totalFemales;
    document.getElementById("totalChildren").textContent = totalChildren;

    const tableBody = document.getElementById("recordsTable");
    tableBody.innerHTML = "";
    records.forEach(record => {
        const row = document.createElement("tr");
        row.innerHTML = `<td>${record.name}</td><td>${record.gender}</td><td>${record.visitor}</td>`;
        tableBody.appendChild(row);
    });
}
document.getElementById("exportCSV").addEventListener("click", function () {
    let records = JSON.parse(localStorage.getItem("churchRecords")) || [];
    if (records.length === 0) {
        alert("No data to export!");
        return;
    }

    let csvContent = "data:text/csv;charset=utf-8,Name,Gender,Visitor\n";
    records.forEach(record => {
        csvContent += `${record.name},${record.gender},${record.visitor}\n`;
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "church_attendance.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
});
document.getElementById("printReport").addEventListener("click", function () {
    let printWindow = window.open('', '', 'width=800,height=600');
    printWindow.document.write('<html><head><title>Church Attendance Report</title>');
    printWindow.document.write('<style> table {width:100%; border-collapse:collapse;} th, td {border:1px solid black; padding:10px; text-align:left;} </style>');
    printWindow.document.write('</head><body>');
    printWindow.document.write('<h2>Church Attendance Report</h2>');
    printWindow.document.write('<table><thead><tr><th>Name</th><th>Gender</th><th>Visitor</th></tr></thead><tbody>');

    let records = JSON.parse(localStorage.getItem("churchRecords")) || [];
    records.forEach(record => {
        printWindow.document.write(`<tr><td>${record.name}</td><td>${record.gender}</td><td>${record.visitor}</td></tr>`);
    });

    printWindow.document.write('</tbody></table>');
    printWindow.document.write('</body></html>');
    printWindow.document.close();
    printWindow.print();
});
document.getElementById("loginForm").addEventListener("submit", function(event) {
    event.preventDefault();

    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    // Example admin credentials (Replace with database authentication later)
    const adminUser = "admin";
    const adminPass = "12345";

    if (username === adminUser && password === adminPass) {
        localStorage.setItem("isAuthenticated", "true");
        window.location.href = "index.html";  // Redirect to the main dashboard
    } else {
        document.getElementById("errorMessage").innerText = "Invalid username or password!";
    }
});

// Logout function
function logout() {
    localStorage.removeItem("isAuthenticated");
    window.location.href = "login.html";  // Redirect to login
}

// Check authentication on protected pages
function checkAuth() {
    if (localStorage.getItem("isAuthenticated") !== "true") {
        window.location.href = "login.html";  // Redirect if not logged in
    }
}
function logout() {
    localStorage.removeItem("isAuthenticated");
    localStorage.removeItem("role");
    window.location.href = "login.html";  // Redirect to login page
}
